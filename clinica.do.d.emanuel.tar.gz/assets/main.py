import asyncio
import os
import random
import sys
import pygame

pygame.init()

LARGURA, ALTURA = 1280, 720
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Dr. Emanuel — Consultório")
relogio = pygame.time.Clock()

PASTA_BASE = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else "."
PASTA_ASSETS = os.path.join(PASTA_BASE, "assets")


def carregar_fonte(nome_ficheiro, familia_sys, tamanho, bold=False):
    caminho_ttf = os.path.join(PASTA_ASSETS, nome_ficheiro)
    if os.path.exists(caminho_ttf):
        return pygame.font.Font(caminho_ttf, tamanho)
    return pygame.font.SysFont(familia_sys, tamanho, bold=bold)


# Fontes personalizadas para capturar o estilo retro pixelado/arredondado em 1280x720
fonte_titulo = carregar_fonte("titulo.ttf", "impact", 52)
fonte_sub = carregar_fonte("texto.ttf", "arial", 23, bold=True)
fonte_texto = carregar_fonte("texto.ttf", "arial", 24, bold=True)
fonte_papel = carregar_fonte("papel.ttf", "consolas", 25, bold=True)
fonte_botoes = carregar_fonte("texto.ttf", "arial", 24, bold=True)

# Paleta de Cores baseada na interface enviada
COR_TEXTO_ESCURO = (44, 25, 20)
COR_TEXTO_BOTAO = (255, 255, 255)
COR_FUNDO_PLACA = (254, 246, 222)
COR_BORDA_PLACA = (44, 115, 105)
COR_INTERNA_PLACA = (248, 235, 196)

# Azul e efeitos para Botão "Iniciar Run" e opções
COR_AZUL_ESC = (16, 54, 178)
COR_AZUL_BRILHO = (10, 115, 242)
COR_AZUL_HOVER = (60, 150, 255)
COR_BORDA_AZUL = (255, 255, 255)

CORES_FUNDO = {
    "intro": (22, 26, 36),
    "consulta": (28, 34, 48),
    "diagnostico": (26, 32, 46),
    "tratamento": (26, 32, 46),
    "final_bom": (24, 46, 38),
    "game_over": (46, 22, 26),
    "concluido": (24, 46, 38),
}

IMAGENS_FUNDO = {
    "intro": "intro",
    "consulta": "consulta",
    "diagnostico": "diagnostico",
    "tratamento": "tratamento",
    "final_bom": "final_bom",
    "game_over": "game_over",
    "concluido": "final_bom",
}

CASOS = [
    {
        "titulo_caso": "Caso 1",
        "historia": (
            "Dr. Emanuel, entram no consultório. O casal explica que tenta "
            "engravidar há algum tempo sem sucesso e que a situação tem sido "
            "desgastante. Entregam-te este livro de registos e exames:"
        ),
        "livro_paginas": [
            [
                "=== LIVRO CLÍNICO: MULHER ===",
                "Nome: Cristina Guerra | Idade: 29 anos",
                "Histórico familiar: Sem infertilidade",
                "Menarca: 13 anos",
                "Contracetivo anterior: Pílula",
                "Filhos: 1 filho (9 anos, outra relação)",
                "Abortos anteriores: Não | Álcool regular: Não",
            ],
            [
                "=== EXAMES MULHER (PARTE 1) ===",
                "Exame Físico Geral: Normal",
                "Peso: 58 kg | Altura: 1,64 m",
                "Exame Mamário: Normal",
                "Exame Ginecológico: Normal",
                "Ecografia: Normal",
                "Estudo Pré-Concepcional: Normal",
            ],
            [
                "=== EXAMES MULHER (PARTE 2) ===",
                "Estudo Hormonal: Progesterona 16 ng/ml (elevada)",
                "FSH: 17 miliUI/ml",
                "Teste Pós-Coital: Positivo",
                "Biópsia Endometrial: Endométrio tipo secretor",
                "Histerosalpingografia: Normal",
                "Estudo Imunológico: Normal",
            ],
            [
                "=== LIVRO CLÍNICO: HOMEM ===",
                "Nome: Afonso Pereira | Idade: 30 anos",
                "Menarca: 13 anos",
                "Histórico familiar: Sem infertilidade",
                "Tabaco: 15 cigarros/dia",
                "Álcool regular: Sim",
                "Calor diário: Exposição a elevadas temp.",
            ],
            [
                "=== EXAMES FÍSICOS & ESPERMOGRAMA ===",
                "Exame Físico Geral: Normal | Genital: Normal",
                "Volume: 3,2 | Cor: Branco translúcido",
                "Viscosidade: Normal | Liquefação: Normal",
                "pH: 7,6 | Aglutinação: Ausente",
                "Motilidade: Nula 48% | In situ 10%",
                "Prog. lenta 32% | Prog. rápida 10%",
                "Nº eZ/m: 1 x 10^6 | Total eZ: 42 x 10^6",
            ],
            [
                "=== ESPERMOGRAMA (CONTINUAÇÃO) ===",
                "Vitalidade: 52% | Morfologia: 4%",
                "Hipoosmolaridade: 65%",
                "Leucócitos: 0",
                "Espermatogónias: 0",
                "Espermatócitos I: 3",
                "Espermatócitos II: 0",
            ],
        ],
        "doencas": [
            {"texto": "Oligospermia Grave", "correta": True},
            {"texto": "Varicocelo", "correta": False},
            {"texto": "Endometriose", "correta": False},
        ],
        "tratamentos": [
            {"texto": "Fertilização In Vitro com ICSI", "correta": True},
            {"texto": "Inseminação intrauterina", "correta": False},
            {"texto": "Indução da ovulação", "correta": False},
        ],
    },
    {
        "titulo_caso": "Caso 2",
        "historia": (
            "Dr. Emanuel, surge o caso seguinte no consultório. O casal traz o "
            "livro clínico atualizado e os exames para avaliação:"
        ),
        "livro_paginas": [
            [
                "=== LIVRO CLÍNICO: MULHER ===",
                "Nome: Cristina Guerra | Idade: 30 anos",
                "Histórico familiar: Sem infertilidade",
                "Menarca: 13 anos",
                "Contracetivo anterior: Pílula",
                "Abortos anteriores: Não | Álcool regular: Não",
            ],
            [
                "=== EXAMES MULHER (PARTE 1) ===",
                "Exame Físico Geral: Normal",
                "Peso: 58 kg | Altura: 1,66 m",
                "Exame Mamário: Normal",
                "Exame Ginecológico: Normal",
                "Ecografia: Normal",
                "Estudo Pré-Concepcional: Normal",
            ],
            [
                "=== EXAMES MULHER (PARTE 2) ===",
                "Estudo Hormonal: Progesterona 16 ng/ml (elevada)",
                "FSH: 17 miliUI/ml",
                "Teste Pós-Coital: Positivo",
                "Biópsia Endometrial: Endométrio tipo secretor",
                "Histerosalpingografia: Normal",
                "Estudo Imunológico: Normal",
            ],
            [
                "=== LIVRO CLÍNICO: HOMEM ===",
                "Nome: Afonso Pereira | Idade: 33 anos",
                "Menarca: 13 anos",
                "Histórico familiar: Sem infertilidade",
                "Tabaco: Não fuma | Álcool: Não bebe",
            ],
            [
                "=== EXAMES FÍSICOS & ESPERMOGRAMA ===",
                "Exame Físico Geral: Normal | Genital: Normal",
                "Volume: 3,2 | Cor: Branco translúcido",
                "Viscosidade: Normal | Liquefação: Normal",
                "pH: 7,8 | Aglutinação: Ausente",
                "Motilidade: Nula 48% | In situ 10%",
                "Prog. lenta 32% | Prog. rápida 10%",
                "Nº eZ/m: 16 x 10^6 | Total eZ: 42 x 10^6",
            ],
            [
                "=== ESPERMOGRAMA (CONTINUAÇÃO) ===",
                "Vitalidade: 52% | Morfologia: 0,2%",
                "Hipoosmolaridade: 65%",
                "Leucócitos: 0",
                "Espermatogónias: 0",
                "Espermatócitos I: 1",
                "Espermatócitos II: 0",
            ],
        ],
        "doencas": [
            {"texto": "Teratozoospermia", "correta": True},
            {"texto": "Varicocelo", "correta": False},
            {"texto": "Endometriose", "correta": False},
        ],
        "tratamentos": [
            {"texto": "Regulação hormonal", "correta": True},
            {"texto": "Inseminação intrauterina", "correta": False},
            {"texto": "Indução da ovulação", "correta": False},
        ],
    },
    {
        "titulo_caso": "Caso 3",
        "historia": (
            "Dr. Emanuel, entra mais um caso no consultório. O casal apresenta "
            "os dados clínicos e os resultados dos exames para análise:"
        ),
        "livro_paginas": [
            [
                "=== LIVRO CLÍNICO: HOMEM ===",
                "Nome: Afonso Pereira | Idade: 38 anos",
                "Menarca: 13 anos",
                "Histórico familiar: Sem infertilidade",
                "Tabaco: Não fuma | Álcool: Não bebe",
            ],
            [
                "=== EXAMES FÍSICOS & ESPERMOGRAMA ===",
                "Exame Físico Geral: Normal",
                "Exame Físico Genital: Dilatação veias espermáticas",
                "Volume: 3,2 | Cor: Branco translúcido",
                "Viscosidade: Normal | Liquefação: Normal",
                "pH: 7,5 | Aglutinação: Ausente",
                "Motilidade: Nula 48% | In situ 10%",
                "Prog. lenta 32% | Prog. rápida 10%",
            ],
            [
                "=== ESPERMOGRAMA (CONTINUAÇÃO) ===",
                "Nº eZ/m: 12 x 10^6 | Total eZ: 42 x 10^6",
                "Vitalidade: 52% | Morfologia: 4%",
                "Hipoosmolaridade: 65%",
                "Leucócitos: 0 | Espermatogónias: 0",
                "Espermatócitos I: 4 | Espermatócitos II: 9",
            ],
            [
                "=== LIVRO CLÍNICO: MULHER ===",
                "Nome: Cristina Guerra | Idade: 31 anos",
                "Histórico familiar: Sem infertilidade",
                "Menarca: 13 anos",
                "Contracetivo anterior: Pílula",
                "Abortos anteriores: Não | Álcool regular: Não",
            ],
            [
                "=== EXAMES MULHER (PARTE 1) ===",
                "Exame Físico Geral: Peso 58 kg | Altura 1,64 m",
                "Exame Mamário: Normal",
                "Exame Ginecológico: Normal",
                "Ecografia: Normal",
                "Estudo Pré-Concepcional: Normal",
            ],
            [
                "=== EXAMES MULHER (PARTE 2) ===",
                "Estudo Hormonal: Progesterona 16 ng/ml (elevada)",
                "FSH: 17 miliUI/ml",
                "Teste Pós-Coital: Positivo",
                "Biópsia Endometrial: Endométrio tipo secretor",
                "Histerosalpingografia: Normal",
                "Estudo Imunológico: Normal",
            ],
        ],
        "doencas": [
            {"texto": "Varicocelo", "correta": True},
            {"texto": "Oligospermia Grave", "correta": False},
            {"texto": "Endometriose", "correta": False},
        ],
        "tratamentos": [
            {"texto": "Reparação cirurgica", "correta": True},
            {"texto": "Inseminação intrauterina", "correta": False},
            {"texto": "Indução da ovulação", "correta": False},
        ],
    },
]


def encontrar_imagem(nome_base):
    if not os.path.isdir(PASTA_ASSETS):
        print(f"[AVISO] Pasta assets não encontrada em: {PASTA_ASSETS}")
        return None

    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        candidato = os.path.join(PASTA_ASSETS, f"{nome_base}{ext}")
        if os.path.exists(candidato):
            return candidato

    for ficheiro in os.listdir(PASTA_ASSETS):
        nome_sem_ext, ext = os.path.splitext(ficheiro)
        if nome_sem_ext.lower() == nome_base.lower() and ext.lower() in (
            ".jpg",
            ".jpeg",
            ".png",
            ".webp",
        ):
            return os.path.join(PASTA_ASSETS, ficheiro)

    return None


def carregar_fundos():
    fundos = {}
    for chave, nome_img in IMAGENS_FUNDO.items():
        caminho = encontrar_imagem(nome_img)
        if caminho:
            print(f"[OK] '{chave}' carregado de: {caminho}")
            img = pygame.image.load(caminho).convert()
            fundos[chave] = pygame.transform.smoothscale(img, (LARGURA, ALTURA))
        else:
            print(f"[FALTA] Não encontrei imagem para '{nome_img}' em: {PASTA_ASSETS}")
            surf = pygame.Surface((LARGURA, ALTURA))
            surf.fill(CORES_FUNDO.get(chave, (22, 26, 36)))
            fundos[chave] = surf
    return fundos


def desenhar_placa_titulo(superficie):
    largura, altura = 680, 236
    x, y = LARGURA // 2 - largura // 2, 92

    pygame.draw.rect(superficie, COR_BORDA_PLACA, (x, y, largura, altura), border_radius=22)
    pygame.draw.rect(superficie, COR_FUNDO_PLACA, (x + 6, y + 6, largura - 12, altura - 12), border_radius=18)
    pygame.draw.rect(
        superficie, COR_BORDA_PLACA, (x + 12, y + 12, largura - 24, altura - 24), width=2, border_radius=14
    )

    img_t1 = fonte_titulo.render("CONSULTÓRIO DO", True, COR_TEXTO_ESCURO)
    img_t2 = fonte_titulo.render("DR. EMANUEL", True, COR_TEXTO_ESCURO)
    img_sub = fonte_sub.render("Jogo de Escolhas Médicas", True, COR_TEXTO_ESCURO)

    superficie.blit(img_t1, img_t1.get_rect(center=(LARGURA // 2, y + 65)))
    superficie.blit(img_t2, img_t2.get_rect(center=(LARGURA // 2, y + 125)))
    superficie.blit(img_sub, img_sub.get_rect(center=(LARGURA // 2, y + 185)))


def desenhar_botao_arredondado(superficie, rect, texto, mouse_pos, destacado=False, cor_base=COR_AZUL_ESC):
    hover = rect.collidepoint(mouse_pos)

    if destacado or hover:
        brilho_cor = COR_AZUL_BRILHO if destacado else COR_AZUL_HOVER
        for expand in range(4, 0, -1):
            pygame.draw.rect(
                superficie,
                brilho_cor,
                (rect.x - expand, rect.y - expand, rect.width + expand * 2, rect.height + expand * 2),
                border_radius=rect.height // 2 + expand,
                width=2,
            )

    cor_final = COR_AZUL_HOVER if hover else cor_base
    pygame.draw.rect(superficie, cor_final, rect, border_radius=rect.height // 2)

    borda_interna = COR_BORDA_AZUL if (destacado or hover) else (8, 30, 96)
    pygame.draw.rect(superficie, borda_interna, rect, width=2, border_radius=rect.height // 2)

    img = fonte_botoes.render(texto, True, COR_TEXTO_BOTAO)
    superficie.blit(img, img.get_rect(center=rect.center))


def desenhar_caixa_translucida(superficie, rect, cor_rgba=(24, 28, 40, 210), borda=COR_BORDA_PLACA):
    surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(surf, cor_rgba, surf.get_rect(), border_radius=18)
    pygame.draw.rect(surf, borda, surf.get_rect(), width=2, border_radius=18)
    superficie.blit(surf, rect.topleft)


def desenhar_livro_exames(superficie, rect, pagina_idx, total_paginas, paginas):
    """Desenha o bloco de exames com aspeto de livro aberto/caderno clínico."""
    pygame.draw.rect(superficie, COR_BORDA_PLACA, rect, border_radius=14)
    pagina_rect = pygame.Rect(rect.x + 10, rect.y + 10, rect.width - 20, rect.height - 20)
    pygame.draw.rect(superficie, COR_FUNDO_PLACA, pagina_rect, border_radius=10)

    lombada_x = pagina_rect.x + 28
    pygame.draw.line(
        superficie,
        (195, 178, 138),
        (lombada_x, pagina_rect.y + 10),
        (lombada_x, pagina_rect.bottom - 10),
        2,
    )

    linhas_pagina = paginas[pagina_idx]
    y = pagina_rect.y + 18
    for linha in linhas_pagina:
        img = fonte_papel.render(linha, True, COR_TEXTO_ESCURO)
        superficie.blit(img, (lombada_x + 16, y))
        y += fonte_papel.get_linesize() + 6

    rodape = fonte_sub.render(
        f"Página {pagina_idx + 1} de {total_paginas}",
        True,
        COR_BORDA_PLACA,
    )
    superficie.blit(rodape, (pagina_rect.right - rodape.get_width() - 20, pagina_rect.bottom - 34))


def quebrar_texto(texto, fonte, largura_max):
    palavras = texto.split(" ")
    linhas = []
    atual = ""
    for p in palavras:
        teste = f"{atual} {p}".strip()
        if fonte.size(teste)[0] <= largura_max:
            atual = teste
        else:
            linhas.append(atual)
            atual = p
    if atual:
        linhas.append(atual)
    return linhas


def desenhar_linhas(superficie, linhas, fonte, cor, x, y, espaco=6):
    for linha in linhas:
        img = fonte.render(linha, True, cor)
        superficie.blit(img, (x, y))
        y += fonte.get_linesize() + espaco
    return y


def preparar_caso(indice):
    caso = CASOS[indice]
    doencas_embaralhadas = random.sample(caso["doencas"], len(caso["doencas"]))
    tratamentos_embaralhados = random.sample(caso["tratamentos"], len(caso["tratamentos"]))
    return caso, doencas_embaralhadas, tratamentos_embaralhados


async def main():
    fundos = carregar_fundos()
    indice_caso = 0
    caso_atual, doencas_atuais, tratamentos_atuais = preparar_caso(indice_caso)
    estado = "intro"  # intro | consulta | diagnostico | tratamento | final_bom | game_over | concluido
    motivo_gameover = ""
    pagina_livro = 0

    rodando = True
    while rodando:
        relogio.tick(60)
        mouse_pos = pygame.mouse.get_pos()
        botoes = []
        total_paginas = len(caso_atual["livro_paginas"])

        if estado == "intro":
            btn_iniciar = pygame.Rect(LARGURA // 2 - 180, 368, 360, 64)
            botoes.append((btn_iniciar, ("comecar_casos", None), "INICIAR RUN", True))

        elif estado == "consulta":
            btn_anterior = pygame.Rect(80, ALTURA - 86, 210, 54)
            btn_seguinte = pygame.Rect(306, ALTURA - 86, 210, 54)
            btn_avancar = pygame.Rect(LARGURA - 330, ALTURA - 86, 250, 54)

            botoes.append((btn_anterior, ("pagina", -1), "Pág. Anterior", False))
            botoes.append((btn_seguinte, ("pagina", 1), "Pág. Seguinte", False))
            botoes.append((btn_avancar, ("ir", "diagnostico"), "Analisar Doenças", True))

        elif estado == "diagnostico":
            for i, item in enumerate(doencas_atuais):
                rect = pygame.Rect(160, 260 + i * 82, LARGURA - 320, 62)
                rotulo = f"{i + 1}. {item['texto']}"
                botoes.append((rect, ("doenca", item["correta"]), rotulo, False))

        elif estado == "tratamento":
            for i, item in enumerate(tratamentos_atuais):
                rect = pygame.Rect(160, 260 + i * 82, LARGURA - 320, 62)
                rotulo = f"{i + 1}. {item['texto']}"
                botoes.append((rect, ("tratamento", item["correta"]), rotulo, False))

        elif estado == "final_bom":
            if indice_caso + 1 < len(CASOS):
                btn_proximo = pygame.Rect(LARGURA // 2 - 200, 480, 400, 58)
                botoes.append((btn_proximo, ("proximo_caso", None), "Próximo Caso", True))
            else:
                btn_concluir = pygame.Rect(LARGURA // 2 - 200, 480, 400, 58)
                botoes.append((btn_concluir, ("ir", "concluido"), "Ver Resumo Final", True))

        elif estado == "game_over":
            btn_recomecar = pygame.Rect(LARGURA // 2 - 200, 480, 400, 58)
            botoes.append((btn_recomecar, ("recomecar_caso", None), "Recomeçar Caso", True))

        elif estado == "concluido":
            btn_voltar = pygame.Rect(LARGURA // 2 - 180, 480, 360, 58)
            botoes.append((btn_voltar, ("ir", "intro"), "Voltar ao Início", True))

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False

            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                for rect, acao, _, _ in botoes:
                    if rect.collidepoint(evento.pos):
                        tipo, valor = acao
                        if tipo == "comecar_casos":
                            indice_caso = 0
                            caso_atual, doencas_atuais, tratamentos_atuais = preparar_caso(indice_caso)
                            pagina_livro = 0
                            motivo_gameover = ""
                            estado = "consulta"
                        elif tipo == "pagina":
                            pagina_livro = (pagina_livro + valor) % total_paginas
                        elif tipo == "recomecar_caso":
                            caso_atual, doencas_atuais, tratamentos_atuais = preparar_caso(indice_caso)
                            pagina_livro = 0
                            motivo_gameover = ""
                            estado = "consulta"
                        elif tipo == "proximo_caso":
                            indice_caso += 1
                            caso_atual, doencas_atuais, tratamentos_atuais = preparar_caso(indice_caso)
                            pagina_livro = 0
                            motivo_gameover = ""
                            estado = "consulta"
                        elif tipo == "ir":
                            if valor == "intro":
                                indice_caso = 0
                                caso_atual, doencas_atuais, tratamentos_atuais = preparar_caso(indice_caso)
                                pagina_livro = 0
                                motivo_gameover = ""
                            estado = valor
                        elif tipo == "doenca":
                            if valor:
                                estado = "tratamento"
                            else:
                                motivo_gameover = "Diagnóstico incorreto."
                                estado = "game_over"
                        elif tipo == "tratamento":
                            if valor:
                                estado = "final_bom"
                            else:
                                motivo_gameover = "Tratamento incorreto."
                                estado = "game_over"
                        break

        tela.blit(fundos[estado], (0, 0))

        if estado == "intro":
            desenhar_placa_titulo(tela)

        elif estado == "consulta":
            caixa = pygame.Rect(80, 32, LARGURA - 160, 576)
            desenhar_caixa_translucida(tela, caixa)

            cabecalho = f"{caso_atual['titulo_caso']} ({indice_caso + 1}/{len(CASOS)}) — {caso_atual['historia']}"
            linhas_h = quebrar_texto(cabecalho, fonte_texto, caixa.width - 48)
            y_apos = desenhar_linhas(tela, linhas_h, fonte_texto, (242, 245, 250), caixa.left + 24, caixa.top + 18)

            livro_topo = y_apos + 14
            livro_altura = max(260, caixa.bottom - livro_topo - 20)
            livro_rect = pygame.Rect(caixa.left + 24, livro_topo, caixa.width - 48, livro_altura)
            desenhar_livro_exames(tela, livro_rect, pagina_livro, total_paginas, caso_atual["livro_paginas"])

        elif estado == "diagnostico":
            caixa_d = pygame.Rect(110, 58, LARGURA - 220, 146)
            desenhar_caixa_translucida(tela, caixa_d, cor_rgba=(8, 30, 68, 220), borda=(15, 82, 148))
            img = fonte_titulo.render(f"{caso_atual['titulo_caso'].upper()}: QUAL A CAUSA?", True, (255, 255, 255))
            tela.blit(img, img.get_rect(center=(LARGURA // 2, 106)))
            sub = fonte_sub.render("Com base no relato e no livro, qual é o diagnóstico?", True, (140, 182, 235))
            tela.blit(sub, sub.get_rect(center=(LARGURA // 2, 162)))

        elif estado == "tratamento":
            caixa_tr = pygame.Rect(110, 58, LARGURA - 220, 146)
            desenhar_caixa_translucida(tela, caixa_tr, cor_rgba=(8, 30, 68, 220), borda=(15, 82, 148))
            img = fonte_titulo.render(f"{caso_atual['titulo_caso'].upper()}: QUAL A SOLUÇÃO?", True, (255, 255, 255))
            tela.blit(img, img.get_rect(center=(LARGURA // 2, 106)))
            sub = fonte_sub.render("Diagnóstico confirmado. Qual tratamento vais aplicar?", True, (140, 182, 235))
            tela.blit(sub, sub.get_rect(center=(LARGURA // 2, 162)))

        elif estado == "final_bom":
            caixa = pygame.Rect(140, 132, LARGURA - 280, 288)
            desenhar_caixa_translucida(tela, caixa)
            txt = (
                f"{caso_atual['titulo_caso']} concluído com sucesso! Com o diagnóstico "
                "e o tratamento certos, o casal regressa ao consultório tempos depois "
                "para agradecer ao Dr. Emanuel."
            )
            desenhar_linhas(
                tela,
                quebrar_texto(txt, fonte_texto, caixa.width - 56),
                fonte_texto,
                (242, 245, 250),
                caixa.left + 28,
                caixa.top + 42,
            )

        elif estado == "game_over":
            caixa_go = pygame.Rect(LARGURA // 2 - 420, 162, 840, 216)
            desenhar_caixa_translucida(tela, caixa_go)
            img = fonte_titulo.render("GAME OVER", True, (235, 95, 95))
            tela.blit(img, img.get_rect(center=(LARGURA // 2, 216)))
            sub = fonte_texto.render(f"{caso_atual['titulo_caso']}: {motivo_gameover}", True, (242, 245, 250))
            tela.blit(sub, sub.get_rect(center=(LARGURA // 2, 298)))

        elif estado == "concluido":
            caixa_c = pygame.Rect(140, 132, LARGURA - 280, 288)
            desenhar_caixa_translucida(tela, caixa_c)
            txt = (
                f"Completaste os {len(CASOS)} casos clínicos no consultório do "
                "Dr. Emanuel! Podes voltar ao início para repetir a sequência."
            )
            desenhar_linhas(
                tela,
                quebrar_texto(txt, fonte_texto, caixa_c.width - 56),
                fonte_texto,
                (242, 245, 250),
                caixa_c.left + 28,
                caixa_c.top + 42,
            )

        for rect, _, rotulo, destacado in botoes:
            desenhar_botao_arredondado(tela, rect, rotulo, mouse_pos, destacado=destacado)

        pygame.display.flip()
        await asyncio.sleep(0)

    if not sys.platform.startswith("emscripten"):
        pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())